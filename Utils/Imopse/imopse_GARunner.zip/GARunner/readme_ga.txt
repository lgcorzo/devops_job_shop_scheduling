iMOPSE ga-greedy runner - User�s Manual
Maciej Laszczyk, Pawel B. Myszkowski
maciej.laszczyk@pwr.edu.pl; pawel.myszkowski@pwr.edu.pl
Project page: http://imopse.ii.pwr.wroc.pl/
Wroclaw University of Technology
April 17, 2017  

Reference
Myszkowski P.B., Laszczyk M., Nikulin I., Skowronski M.E."iMOPSE: a library for bicriteria optimization in Multi�Skill Resource�Constrained Project Scheduling Problem", in review process, Soft Computing Journal.

parameters:
population_size - number of individuals in the population
generation_limit - maximum number of generations to create
evaluation_rate - weights assigned to cost and duration criteria (0.0 - cost only, 1.0 - duration only)
mutation_probability - probability, with which to mutate each gene
initial_population_type - currently only RANDOM available
selection_type - currently only ROULETTE_WHEEL available
crossover_type - currently only SINGLE_POINT available
mutation_type - currently only RANDOM available
schedule_builder_type - FORWARD_SCHEDULE_BUILDER or BACKWARD_SCHEDULE_BUILDER
definition_file - file path to the .def file

example use:
java -jar GARunner.jar 100 100 1.0 0.1 RANDOM ROULETTE_WHEEL SINGLE_POINT RANDOM FORWARD_SCHEDULE_BUILDER definitions\100_10_26_15.def