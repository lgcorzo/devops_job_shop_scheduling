iMOPSE greedy runner - User�s Manual
Maciej Laszczyk, Pawel B. Myszkowski
maciej.laszczyk@pwr.edu.pl; pawel.myszkowski@pwr.edu.pl
Project page: http://imopse.ii.pwr.wroc.pl/
Wroclaw University of Technology
April 17, 2017  

Reference
Myszkowski P.B., Laszczyk M., Nikulin I., Skowronski M.E."iMOPSE: a library for bicriteria optimization in Multi�Skill Resource�Constrained Project Scheduling Problem", in review process, Soft Computing Journal.

parameters: 
evaluation_type - either 'cost' or 'duration'
definition_file - file path to the .def file

example use:
java -jar GreedyRunner.jar duration definitions\100_10_26_15.def