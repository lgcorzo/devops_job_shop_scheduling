iMOPSE instances generator- User's Manual
Pawel B. Myszkowski
maciej.laszczyk@pwr.edu.pl; pawel.myszkowski@pwr.edu.pl
Project page: http://imopse.ii.pwr.wroc.pl/
Wroclaw University of Technology
April 17, 2017  

Reference
Myszkowski P.B., Skowroński M., Sikora K., "A new benchmark dataset for Multi-Skill Resource-Constrained Project Scheduling Problem", Proceedings of the 2015 Federated Conference on Computer Science and Information Systems, M. Ganzha, L. Maciaszek, M. Paprzycki (eds). ACSIS, Vol. 5, pages 129–138 (2015) 

parameters:

example use:
java -jar generator.jar
